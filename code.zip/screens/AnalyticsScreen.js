import React, { useCallback, useState } from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Card } from '../components/UI';
import { colors, spacing } from '../utils/theme';
import { getWorkoutDates, getWorkouts } from '../utils/storage';
import WorkoutCalendar from '../components/WorkoutCalendar';

export default function AnalyticsScreen() {
  const [workouts, setWorkouts] = useState([]);
  const [workoutDates, setWorkoutDates] = useState([]);

  useFocusEffect(
    useCallback(() => {
      Promise.all([getWorkouts(), getWorkoutDates()]).then(([w, dates]) => {
        setWorkouts(w.sort((a, b) => new Date(a.date) - new Date(b.date)));
        setWorkoutDates(dates);
      });
    }, [])
  );

  if (workouts.length === 0) {
    return (
      <View style={styles.center}>
        <Text style={{ color: colors.muted }}>Log a few workouts to see analytics.</Text>
      </View>
    );
  }

  // Total volume per workout
  const volumeByWorkout = workouts.map((w) => ({
    date: w.date,
    volume: w.exercises.reduce(
      (sum, e) => sum + e.sets.reduce((s, x) => s + x.weight * x.reps, 0),
      0
    ),
  }));

  const totalWeightLifted = volumeByWorkout.reduce((a, w) => a + w.volume, 0);
  const totalSets = workouts.reduce(
    (a, w) => a + w.exercises.reduce((s, e) => s + e.sets.length, 0),
    0
  );

  // Progress score: compare each exercise's most recent top weight vs its first recorded top weight
  const exerciseIds = [...new Set(workouts.flatMap((w) => w.exercises.map((e) => e.exerciseId)))];
  let improved = 0, maintained = 0, declined = 0;
  exerciseIds.forEach((id) => {
    const sessions = workouts
      .filter((w) => w.exercises.some((e) => e.exerciseId === id))
      .map((w) => w.exercises.find((e) => e.exerciseId === id));
    if (sessions.length < 2) { maintained++; return; }
    const first = Math.max(...sessions[0].sets.map((s) => s.weight));
    const last = Math.max(...sessions[sessions.length - 1].sets.map((s) => s.weight));
    if (last > first) improved++;
    else if (last < first) declined++;
    else maintained++;
  });
  const totalTracked = improved + maintained + declined;
  const progressScore = totalTracked ? Math.round((improved / totalTracked) * 100) : 0;

  const recentVolumes = volumeByWorkout.slice(-6);
  const maxVolume = Math.max(...recentVolumes.map((item) => item.volume), 1);

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: spacing.md, paddingBottom: 40 }}>
      <Card style={{ marginBottom: spacing.md, alignItems: 'center', minHeight: 180 }}>
        <Text style={styles.scoreLabel}>Progress Score</Text>
        <Text style={styles.scoreValue}>{progressScore}%</Text>
        <View style={styles.scoreBreakdown}>
          <Text style={styles.breakdownText}>↑ {improved} improved</Text>
          <Text style={styles.breakdownText}>→ {maintained} maintained</Text>
          <Text style={styles.breakdownText}>↓ {declined} declined</Text>
        </View>
      </Card>

      <View style={styles.statsGrid}>
        <Card style={styles.statCard}>
          <Text style={styles.statLabel}>Total Weight Lifted</Text>
          <Text style={styles.statValue}>{Math.round(totalWeightLifted).toLocaleString()}kg</Text>
        </Card>
        <Card style={styles.statCard}>
          <Text style={styles.statLabel}>Total Sets</Text>
          <Text style={styles.statValue}>{totalSets}</Text>
        </Card>
        <Card style={styles.statCard}>
          <Text style={styles.statLabel}>Workouts</Text>
          <Text style={styles.statValue}>{workouts.length}</Text>
        </Card>
      </View>

      {recentVolumes.length > 1 && (
        <Card style={{ marginTop: spacing.md }}>
          <Text style={styles.chartTitle}>Volume Per Workout (recent)</Text>
          <View style={styles.chartBars}>
            {recentVolumes.map((item, index) => (
              <View key={index} style={styles.barColumn}>
                <View style={[styles.barFill, { height: Math.max(24, (item.volume / maxVolume) * 120) }]} />
                <Text style={styles.barLabel}>{index + 1}</Text>
              </View>
            ))}
          </View>
          <Text style={styles.chartHint}>Recent loads are shown in a simple bar chart based on your logged volume.</Text>
        </Card>
      )}

      <Card style={{ marginTop: spacing.md }}>
        <Text style={styles.chartTitle}>Workout Calendar</Text>
        <WorkoutCalendar workoutDates={workoutDates} />
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg, padding: spacing.lg },
  scoreLabel: { color: colors.muted, fontSize: 13, fontWeight: '700', textTransform: 'uppercase' },
  scoreValue: { color: colors.accent, fontSize: 48, fontWeight: '900', marginVertical: spacing.xs },
  scoreBreakdown: { flexDirection: 'row', gap: spacing.md, marginTop: spacing.xs },
  breakdownText: { color: colors.muted, fontSize: 12, fontWeight: '600' },
  statsGrid: { flexDirection: 'row', gap: spacing.sm },
  statCard: { flex: 1, alignItems: 'center' },
  statLabel: { color: colors.muted, fontSize: 11, fontWeight: '600', marginBottom: 4, textAlign: 'center' },
  statValue: { color: colors.text, fontSize: 16, fontWeight: '800' },
  chartTitle: { color: colors.muted, fontSize: 12, fontWeight: '700', marginBottom: spacing.sm, textTransform: 'uppercase' },
  chartBars: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', height: 140, marginTop: spacing.sm },
  barColumn: { flex: 1, alignItems: 'center', marginHorizontal: 4 },
  barFill: { width: '100%', maxWidth: 24, borderRadius: 8, backgroundColor: colors.accent, minHeight: 12 },
  barLabel: { color: colors.muted, fontSize: 11, marginTop: spacing.xs },
  chartHint: { color: colors.muted, fontSize: 12, marginTop: spacing.sm },
});
