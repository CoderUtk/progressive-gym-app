import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StatusBar } from 'expo-status-bar';
import { Text } from 'react-native';

import DashboardScreen from '../screens/DashboardScreen';
import WorkoutLoggerScreen from '../screens/WorkoutLoggerScreen';
import ExerciseLibraryScreen from '../screens/ExerciseLibraryScreen';
import ExerciseHistoryScreen from '../screens/ExerciseHistoryScreen';
import AnalyticsScreen from '../screens/AnalyticsScreen';
import TemplateSelectScreen from '../screens/TemplateSelectScreen';
import ExercisePickerScreen from '../screens/ExercisePickerScreen';
import WelcomeScreen from '../screens/WelcomeScreen';
import DailyPlanScreen from '../screens/DailyPlanScreen';
import { colors } from '../utils/theme';
import { hasSeenOnboarding, clearAllData } from '../utils/storage';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function Icon({ label, focused }) {
  return <Text style={{ fontSize: 20, opacity: focused ? 1 : 0.4 }}>{label}</Text>;
}

function HomeTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.bg },
        headerTitleStyle: { color: colors.text, fontWeight: '700' },
        headerShadowVisible: false,
        tabBarStyle: { backgroundColor: colors.bg, borderTopColor: colors.border },
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: colors.muted,
      }}
    >
      <Tab.Screen name="Dashboard" component={DashboardScreen} options={{ tabBarIcon: ({ focused }) => <Icon label="🏠" focused={focused} />, title: 'Progressive' }} />
      <Tab.Screen name="Exercises" component={ExerciseLibraryScreen} options={{ tabBarIcon: ({ focused }) => <Icon label="🔍" focused={focused} />, title: 'Exercises' }} />
      <Tab.Screen name="Analytics" component={AnalyticsScreen} options={{ tabBarIcon: ({ focused }) => <Icon label="📈" focused={focused} />, title: 'Analytics' }} />
    </Tab.Navigator>
  );
}

export default function AppRoot() {
  const [initialRoute, setInitialRoute] = useState('Loading');

  useEffect(() => {
    async function init() {
      const seen = await hasSeenOnboarding();
      if (!seen) {
        await clearAllData();
      }
      setInitialRoute(seen ? 'Home' : 'Welcome');
    }
    init();
  }, []);

  if (initialRoute === 'Loading') {
    return (
      <View style={{ flex: 1, backgroundColor: colors.bg, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator color={colors.accent} size="large" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <StatusBar style="light" />
      <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: colors.bg }, headerTitleStyle: { color: colors.text }, headerTintColor: colors.text, headerShadowVisible: false }}>
        <Stack.Screen name="Welcome" component={WelcomeScreen} options={{ headerShown: false }} />
        <Stack.Screen name="DailyPlan" component={DailyPlanScreen} options={{ title: 'Choose Workout' }} />
        <Stack.Screen name="Home" component={HomeTabs} options={{ headerShown: false }} />
        <Stack.Screen name="WorkoutLogger" component={WorkoutLoggerScreen} options={{ title: 'Log Workout' }} />
        <Stack.Screen name="ExerciseHistory" component={ExerciseHistoryScreen} options={{ title: 'Exercise History' }} />
        <Stack.Screen name="TemplateSelect" component={TemplateSelectScreen} options={{ title: "Today's Workout" }} />
        <Stack.Screen name="ExercisePicker" component={ExercisePickerScreen} options={{ title: 'Select Exercises' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
