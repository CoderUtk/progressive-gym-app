import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, spacing } from '../utils/theme';

export default function WorkoutCalendar({ workoutDates }) {
  const today = new Date();
  const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
  const offset = startOfMonth.getDay();
  const cells = [];

  for (let i = 0; i < offset; i += 1) {
    cells.push(<View key={`empty-${i}`} style={styles.cell} />);
  }

  for (let day = 1; day <= daysInMonth; day += 1) {
    const date = new Date(today.getFullYear(), today.getMonth(), day);
    const key = date.toISOString().slice(0, 10);
    const workedOut = workoutDates.includes(key);
    cells.push(
      <View key={key} style={[styles.cell, workedOut ? styles.workedOutCell : styles.emptyCell]}>
        <Text style={[styles.dayText, workedOut && styles.workedOutText]}>{day}</Text>
      </View>
    );
  }

  return (
    <View style={styles.grid}>
      {cells}
    </View>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap' },
  cell: {
    width: '13.8%',
    aspectRatio: 1,
    margin: 1,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  emptyCell: { backgroundColor: colors.card },
  workedOutCell: { backgroundColor: colors.accent },
  dayText: { color: colors.text, fontSize: 12, fontWeight: '700' },
  workedOutText: { color: colors.bg },
});
